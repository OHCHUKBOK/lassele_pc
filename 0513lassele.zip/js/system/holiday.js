    document.addEventListener('DOMContentLoaded', function () {
        const calendarEl = document.getElementById('calendar');
        const closedDays = {}; // 날짜별 상태 저장

        const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: 'ko',
        selectable: true,
        
        eventClick: function (info) {
            const isDelete = confirm(`'${info.event.title}' 일정을 삭제하시겠습니까?`);
            if (isDelete) {
            info.event.remove();
            }
        },
        dateClick: function (info) {
            const target = info.jsEvent.target;
            const dateStr = info.dateStr;

            //토글 버튼 클릭한 경우
            const toggleBtn = target.closest('.toggle-btn');
            if (toggleBtn) {
            const isClosed = toggleBtn.classList.contains('closed');

            // 상태 변경
            if (isClosed) {
                delete closedDays[dateStr];
            } else {
                closedDays[dateStr] = true;
            }

            // UI 반영
            toggleBtn.textContent = isClosed ? '영업중' : '휴무';
            toggleBtn.classList.toggle('closed', !isClosed);

            return; // 일정 등록은 막기
            }

            // 그 외 영역 클릭 시 스케줄 등록
            const title = prompt('스케줄 제목을 입력하세요');
            if (title) {
            calendar.addEvent({
                title,
                start: dateStr,
                allDay: true
            });
            }
        },

        dayCellDidMount: function (info) {
            const dateStr = info.date.toISOString().split('T')[0];

            const toggleBtn = document.createElement('button');
            toggleBtn.className = 'toggle-btn';
            toggleBtn.textContent = closedDays[dateStr] ? '휴무' : '영업중';

            if (closedDays[dateStr]) {
            toggleBtn.classList.add('closed');
            }

            // 렌더링만 — 클릭은 dateClick에서 처리
            const topEl = info.el.querySelector('.fc-daygrid-day-top');
            if (topEl) {
            topEl.appendChild(toggleBtn);
            }
        }
        });

        calendar.render();
    });